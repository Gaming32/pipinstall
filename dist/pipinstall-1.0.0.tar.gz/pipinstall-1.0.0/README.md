# Running
Basic usage: `python -m pipinstall <packages>`.
Run `python -m pipinstall --help` for more info.
## Uninstalling Packages
To uninstall packages either run `pipuninstall` instead, or pass the `--uninstall` flag to `pipinstall`.