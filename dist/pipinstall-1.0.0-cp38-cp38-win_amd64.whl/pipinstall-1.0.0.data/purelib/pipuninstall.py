import pipinstall

__version__ = pipinstall.__version__

def main():
    pipinstall.main(True)

if __name__ == '__main__': main()